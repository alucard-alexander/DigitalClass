package com.example.digitalclass.Constants;

public class ConstantsVariables {

    public static final int PERMISSION_STORAGE_CODE =1000;
    public static final String SHARED_PREFERENCE_VALUE = "sharedPreferenceDigitalCare";

}
